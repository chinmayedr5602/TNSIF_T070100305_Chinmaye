package com.tnsif.Adminservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.persistence.NoResultException;

@RestController
public class AdminController {

	@Autowired
	private AdminService service;
	
	@GetMapping("/Adminservice")
	public List<Admin> list()
	{
		return service.listAllRecords();
	}
	
	@PostMapping("/Adminservice")
	public void add(@RequestBody Admin cust)
	{
		service.insertRecord(cust);
	}
	
	@GetMapping("/Adminservice/{id}")
	public ResponseEntity<Admin> get(@PathVariable Integer id)
	{
		try
		{
			Admin cust=service.getParticularRecord(id);
			return new ResponseEntity<Admin>(cust,HttpStatus.OK);
		}
		catch(NoResultException e)
		{
			return new ResponseEntity<Admin>(HttpStatus.NOT_FOUND);
		}
	}
	
	@DeleteMapping("/Adminservice/{id}")
	public void delete(@PathVariable Integer id)
	{
		service.delete(id);
	}
	
	 @PutMapping("/Adminservice/{id}")
	 public ResponseEntity<Void> updateCustomer(@PathVariable Integer id, @RequestBody Admin updatedCustomer) 
	 {   
		 updatedCustomer.setCid(id);
	     service.update(updatedCustomer);
	     return new ResponseEntity<>(HttpStatus.OK);
	  }
	
	
}
