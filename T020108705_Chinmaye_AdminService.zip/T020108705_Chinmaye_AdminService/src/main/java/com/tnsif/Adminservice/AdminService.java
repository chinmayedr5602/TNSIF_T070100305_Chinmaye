package com.tnsif.Adminservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class AdminService {

	@Autowired
	private AdminRepository repo;
	
	//Insert the record into the database
	public void insertRecord(Admin cust)
	{
		repo.save(cust);
	}
	
	//Get all the records from the table
	public List<Admin> listAllRecords()
	{
		return repo.findAll();
	}
	
	//Retrieving the particular record
	public Admin getParticularRecord(Integer id)
	{
		return repo.findById(id).get();
	}
	
	//Deleting the record method
	public void delete(Integer id)
	{
		repo.deleteById(id);
	}
	
	//Update the record
	public void update(Admin updatedAdmin) {
	    if(repo.existsById(updatedAdmin.getCid())) {	        
	        Admin existingAdmin = repo.findById(updatedAdmin.getCid()).get();
	        existingAdmin.setCname(updatedAdmin.getCname());
	        existingAdmin.setCity(updatedAdmin.getCity());
	        repo.save(existingAdmin);
	    } else {
	        
	        System.out.println("Student with ID " + updatedAdmin .getCid() + " not found. Cannot update.");
	    }
	}

	
	
	
}
